<h2 align="center"> Everblush GTK Theme</h2>

# Preview
<p align="center"> 
  <img src="https://github.com/Mangeshrex/Everblush-gtk/blob/main/assets/Everblush-gtk.png?raw=true">
  <img src="https://img.shields.io/static/v1?label=license&message=MIT&color=8ccf7e&labelColor=22292b&style=for-the-badge">
</p> 

# Installation 
```sh 
git clone https://github.com/mangeshrex/Everblush-gtk
npm install -g scss 
sudo make install 
```

# Credits 💝 
- @siduck 
